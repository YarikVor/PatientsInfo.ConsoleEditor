﻿using System;

namespace ConsoleCMD {
	static class EnterCMD {
		
	}
}
