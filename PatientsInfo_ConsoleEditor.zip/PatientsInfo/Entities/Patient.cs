﻿using System;

namespace PatientsInfo.Entities {
	/// <summary>
	/// Сутність пацієнта
	/// </summary>
	[Serializable]
	public class Patient {

		public static ulong KeyCount = 1;

		/// <summary>
		/// Ключ
		/// </summary>
		public ulong Key { get; private set; }
		/// <summary>
		/// Особа
		/// </summary>
		public Entities.Person Person { get; set; }
		/// <summary>
		/// Хвороба
		/// </summary>
		public Disease disease { get; set; }
		/// <summary>
		/// Чи хворіє
		/// </summary>
		public bool? IsSick { get; set; }
		/// <summary>
		/// Коментарі
		/// </summary>
		public string Comment { get; set; }



public Patient() {
			Key = KeyCount++;
		}
		public Patient(Entities.Person person, Disease disease) : this(person, disease, null, "") { }

		public Patient(Entities.Person person, Disease disease, bool? isSick) : this(person, disease, isSick, "") { }

		public Patient(Entities.Person person, Disease disease, string comment) : this(person, disease, null, comment) { }

		public Patient(Entities.Person person, Disease disease, bool? isSick, string comment) {
			Key = KeyCount++;
			Person = person;
			this.disease = disease;
			IsSick = isSick;
			Comment = comment;
		}

		public override string ToString() {
			return string.Format("{0,4} {1,-30} {2,-20} {3,7} {4}", Key , Person?.FullName, disease?.Name, (IsSick == null) ? "---" : (IsSick == true) ? "Так" : "Ні", Comment);
		}
		public string ToShortString() {
			return string.Format("{0,4} {1,-20} {2,7} {3}", Key, disease?.Name, (IsSick == null) ? "---" : (IsSick == true) ? "Так" : "Ні", Comment);
		}

	}
}
