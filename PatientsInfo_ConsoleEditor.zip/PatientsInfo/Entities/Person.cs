﻿using System;

namespace PatientsInfo.Entities {
	/// <summary>
	/// Клас особи
	/// </summary>
	[Serializable]
	public class Person {
		/// <summary>
		/// Статичний персональний номер;
		/// </summary>
		static ulong PersonalNumberCount = 1;

		/// <summary>
		/// Незмінювальний персональний номер
		/// </summary>
		public ulong PersonalNumber { get; private set; }

		/// <summary>
		/// ПІБ
		/// </summary>
		public string FullName;

		/// <summary>
		/// Дата
		/// </summary>
		public DateTime
			DiseaseOnsetDate,
			DateBirth;

		/// <summary>
		/// Стать
		/// </summary>
		public Enum.Gender Gender;

		/// <summary>
		/// Номер телефона
		/// </summary>
		public string PhoneNumber;

		/// <summary>
		/// Місцепроживання
		/// </summary>
		public string ResidenceAddress;

		/// <summary>
		/// Тип крові
		/// </summary>
		public string TypeBlood;

		/// <summary>
		/// Коментар
		/// </summary>
		public string Comment;

		/// <summary>
		/// Стан здоров'я
		/// </summary>
		public Enum.HealthStatus HealthStatus;


		public Person() {
			PersonalNumber = PersonalNumberCount++;
		}

		public Person(
			string fullName,
			DateTime diseaseOnsetDate,
			DateTime dateBirth,
			Enum.Gender gender,
			Enum.HealthStatus healthStatus,
			string typeBlood,
			string comment = "",
			string phoneNumber = "",
			string residenceAddress = ""
		) : this(fullName, diseaseOnsetDate, dateBirth, gender, phoneNumber, residenceAddress, healthStatus, typeBlood, comment) { }

		public Person(
			string fullName,
			DateTime diseaseOnsetDate,
			DateTime dateBirth,
			Enum.Gender gender,
			string phoneNumber,
			string residenceAddress,
			Enum.HealthStatus healthStatus,
			string typeBlood,
			string comment
		) {
			PersonalNumber = PersonalNumberCount++;
			FullName = fullName;
			DiseaseOnsetDate = diseaseOnsetDate;
			DateBirth = dateBirth;
			Gender = gender;
			PhoneNumber = phoneNumber;
			ResidenceAddress = residenceAddress;
			HealthStatus = healthStatus;
			TypeBlood = typeBlood;
			Comment = comment;
		}

		public override string ToString() {
			return string.Format("{0, 5} {1,-30} {2,10:d} {3,10:d} {4} {5,-4} {6,-13} {7, 14} {8, -40} {9}", PersonalNumber, FullName, DiseaseOnsetDate, DateBirth, Gender.ToStringUA(), TypeBlood, HealthStatus.ToStringUA(), PhoneNumber, ResidenceAddress, Comment);
		}

		public string ToShortString() {
			return string.Format("{0, 5} {1,-30} {2,10:d} {3,10:d} {4} {5,-4} {6}", PersonalNumber, FullName, DiseaseOnsetDate, DateBirth, Gender.ToStringUA(), TypeBlood, HealthStatus.ToStringUA());
		}


	}
}
